import sqlite3
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)

# लॉगिंग सेटअप
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# बॉट कॉन्फिगरेशन
TOKEN = "7801780104:AAGAM--xZM18nJoLWFaAKArddlQxI3osweA"
ADMIN_ID = 7813101887  # अपना टेलीग्राम यूजर आईडी यहाँ डालें

# भाषा विकल्प
LANGUAGES = {
    "hindi": "हिन्दी 🇮🇳",
    "english": "English 🇬🇧"
}

# समस्या कैटेगरीज (हिंदी और इंग्लिश दोनों में)
PROBLEM_CATEGORIES = {
    "love": {"hindi": "प्रेम और रिश्ते 💖", "english": "Love & Relationships 💖"},
    "career": {"hindi": "करियर और नौकरी 💼", "english": "Career & Job 💼"},
    "finance": {"hindi": "धन और वित्त 💰", "english": "Finance & Money 💰"},
    "health": {"hindi": "स्वास्थ्य और तंदुरुस्ती 🏥", "english": "Health & Wellness 🏥"},
    "education": {"hindi": "शिक्षा और विद्या 📚", "english": "Education & Knowledge 📚"}
}

# डेटाबेस सेटअप
def init_db():
    conn = sqlite3.connect('astro_talk.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS problems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        category TEXT,
        problem_text TEXT,
        status TEXT DEFAULT 'pending',
        admin_reply TEXT DEFAULT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    conn.commit()
    conn.close()

init_db()

# भाषा चयन कीबोर्ड
def language_keyboard():
    keyboard = [
        [InlineKeyboardButton(value, callback_data=key)] for key, value in LANGUAGES.items()
    ]
    return InlineKeyboardMarkup(keyboard)

# कैटेगरी कीबोर्ड (मल्टी-लैंग्वेज)
def category_keyboard(language):
    keyboard = []
    for category_code, names in PROBLEM_CATEGORIES.items():
        keyboard.append([InlineKeyboardButton(names[language], callback_data=category_code)])
    return InlineKeyboardMarkup(keyboard)

# स्टार्ट कमांड (अब भाषा चयन के साथ)
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    message = (
        f"Hello {user.first_name}! 🙏\n\n"
        "Please choose your language / कृपया अपनी भाषा चुनें:"
    )
    
    await update.message.reply_text(message, reply_markup=language_keyboard())

# भाषा चयन हैंडलर
async def language_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    language = query.data
    context.user_data['language'] = language
    
    message = {
        "hindi": "कृपया अपनी समस्या की श्रेणी चुनें:",
        "english": "Please select your problem category:"
    }

    await query.edit_message_text(text=message[language], reply_markup=category_keyboard(language))

# कैटेगरी सिलेक्शन हैंडलर
async def category_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    category_code = query.data
    context.user_data['selected_category'] = category_code
    language = context.user_data.get('language', 'english')  # डिफॉल्ट इंग्लिश
    
    category_name = PROBLEM_CATEGORIES[category_code][language]
    messages = {
        "hindi": f"आपने श्रेणी चुनी: {category_name}\n\nअब कृपया अपनी समस्या विस्तार से लिखें।",
        "english": f"You selected: {category_name}\n\nNow please describe your problem in detail."
    }

    await query.edit_message_text(text=messages[language])

# समस्या सबमिट
async def handle_problem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    problem_text = update.message.text
    language = context.user_data.get('language', 'english')

    if 'selected_category' not in context.user_data:
        messages = {
            "hindi": "कृपया पहले /start करें और समस्या की श्रेणी चुनें।",
            "english": "Please start with /start and select a category first."
        }
        await update.message.reply_text(messages[language])
        return
    
    category = context.user_data['selected_category']
    category_name = PROBLEM_CATEGORIES[category][language]

    try:
        conn = sqlite3.connect('astro_talk.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO problems (user_id, username, category, problem_text) VALUES (?, ?, ?, ?)",
            (user.id, user.username, category, problem_text)
        )
        conn.commit()
        
        # एडमिन को नोटिफाई करें
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=f"New Question ({category_name}):\n\n"
                 f"User: @{user.username if user.username else 'N/A'} ({user.id})\n"
                 f"Question: {problem_text}\n\n"
                 f"Reply with /reply {user.id} <your_message>"
        )

        messages = {
            "hindi": f"आपकी {category_name} संबंधी समस्या सबमिट कर दी गई है। हम जल्द ही आपको जवाब देंगे। 🙏",
            "english": f"Your issue related to {category_name} has been submitted. We will respond soon. 🙏"
        }

        await update.message.reply_text(messages[language])
        
    except Exception as e:
        logger.error(f"Error in handle_problem: {e}")
        messages = {
            "hindi": "समस्या सबमिट करने में त्रुटि हुई। कृपया बाद में पुनः प्रयास करें।",
            "english": "Error submitting your issue. Please try again later."
        }
        await update.message.reply_text(messages[language])
        
    finally:
        conn.close()
        if 'selected_category' in context.user_data:
            del context.user_data['selected_category']

# एडमिन का रिप्लाई हैंडलर
async def reply_to_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("❌ यह कमांड केवल एडमिन के लिए है!")
        return

    args = context.args
    if len(args) < 2:
        await update.message.reply_text("⚠️ उपयोग: /reply <user_id> <message>")
        return

    user_id = args[0]
    reply_message = " ".join(args[1:])

    try:
        await context.bot.send_message(chat_id=user_id, text=f"📢 *एडमिन का जवाब:* \n\n{reply_message}", parse_mode="Markdown")
        await update.message.reply_text("✅ रिप्लाई भेज दिया गया!")
    except Exception as e:
        await update.message.reply_text(f"❌ एरर: {str(e)}")

# मुख्य फंक्शन
def main():
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(language_handler, pattern="^(hindi|english)$"))
    application.add_handler(CallbackQueryHandler(category_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_problem))
    application.add_handler(CommandHandler("reply", reply_to_user, filters=filters.User(ADMIN_ID)))

    application.run_polling()

if __name__ == '__main__':
    main()